const board = document.getElementById('board');
const message = document.getElementById('message');
const restartBtn = document.getElementById('restartBtn');
const scoreXDisplay = document.getElementById('scoreX');
const scoreODisplay = document.getElementById('scoreO');
const currentPlayerDisplay = document.getElementById('currentPlayer');

let currentPlayer = 'X';
let gameBoard = ['', '', '','', '', '','', '', ''];
let gameActive = true;
let scoreX = 0;
let scoreO = 0;

function renderBoard() {
    board.innerHTML = '';
    gameBoard.forEach((value, index) => {
        const cell = document.createElement('button');
        cell.classList.add('cell');
        cell.textContent = value;
        cell.dataset.index = index;
        cell.addEventListener('click', handleCellClick);
        board.appendChild(cell);
    });
}

function handleCellClick(event) {
    if (!gameActive) return;

    const cell = event.target;
    const index = cell.dataset.index;

    if (gameBoard[index] !== '') return;
    if (cell.classList.contains('x') ||
        cell.classList.contains('O')) {
            return;
        }

    gameBoard[index] = currentPlayer;
    cell.classList.add(currentPlayer.toLocaleLowerCase());
    

    

    if (checkWinner()) {
        message.textContent = `Игрок ${currentPlayer} победил!`;
        updateScore(currentPlayer);
        gameActive = false;
        return;
    }

    if (gameBoard.every(cell => cell !== '')) {
        message.textContent = 'Ничья!';
        gameActive = false;
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    currentPlayerDisplay.textContent = currentPlayer;
}

function checkWinner() {
    const winCombinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], 
        [0, 3, 6], [1, 4, 7], [2, 5, 8], 
        [0, 4, 8], [2, 4, 6] 
    ];

    for (let combination of winCombinations) {
        const [a, b, c] = combination;
        if (gameBoard[a] !== '' && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            return true;
        }
    }
    return false;
}
function updateScore(player){
  if (player === 'X'){
    scoreX++
    scoreXDisplay.textContent = scoreX
  } else {
    scoreO++
    scoreODisplay.textContent = scoreO
  }
}

function resetGame() {
    gameBoard = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    gameActive = true;
    message.textContent = '';
    currentPlayerDisplay.textContent = currentPlayer
    renderBoard();
}


restartBtn.addEventListener('click', resetGame);

renderBoard();
